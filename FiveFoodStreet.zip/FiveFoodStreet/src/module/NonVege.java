package module;

public class NonVege extends FoodPerson{
	private String meat, addOns;

	public NonVege(String id, String name, String dish, int price, String meat, String addOns) {
		super(id, name, dish, price);
		this.meat = meat;
		this.addOns = addOns;
	}

	public String getMeat() {
		return meat;
	}

	public void setMeat(String meat) {
		this.meat = meat;
	}

	public String getAddOns() {
		return addOns;
	}

	public void setAddOns(String addOns) {
		this.addOns = addOns;
	}

	@Override
	public int calculatePrice() {
		
		return getPrice()+ meatPrice() + dishPrice();
	}
	public int addonsPrice() {
		if(getAddOns().equalsIgnoreCase("Meatballs")) {
			return 4000;
		}else if(getAddOns().equalsIgnoreCase("Fishballs")) {
			return 3000;
		}else if(getAddOns().equalsIgnoreCase("Fried Potato")) {
			return 5000;
		}
		return addonsPrice();
	}
	
	public int meatPrice() {
		if(getMeat().equalsIgnoreCase("Beef")) {
			return getName().length() * 2500;
		}else if(getMeat().equalsIgnoreCase("Chicken")) {
			return getName().length() *1000;
		}else if(getMeat().equalsIgnoreCase("Pork")) {
			return getName().length() *2000;
		}
		return meatPrice();
	}
}
