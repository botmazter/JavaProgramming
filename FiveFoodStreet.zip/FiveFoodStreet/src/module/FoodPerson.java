package module;

public abstract class FoodPerson {
	private String id, name, dish;
	private int price;
	
	public FoodPerson(String id, String name, String dish, int price) {
		super();
		this.setId(id);
		this.name = name;
		this.dish = dish;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDish() {
		return dish;
	}

	public void setDish(String dish) {
		this.dish = dish;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public abstract int calculatePrice();
	
	public int dishPrice() {
		if(getDish().equalsIgnoreCase("Rice")) {
			return 5000;
		}else if(getDish().equalsIgnoreCase("Noodle")) {
			return 3000;
		}
		return price;
			
	}
	
}
