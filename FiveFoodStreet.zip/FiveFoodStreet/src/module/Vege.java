package module;

public class Vege extends FoodPerson{
	private String vegetable;

	public Vege(String id, String name, String dish, int price, String vegetable) {
		super(id, name, dish, price);
		this.vegetable = vegetable;
	}

	public String getVegetable() {
		return vegetable;
	}

	public void setVegetable(String vegetable) {
		this.vegetable = vegetable;
	}

	@Override
	public int calculatePrice() {
	
		return getPrice()+ vegetablePrice() + dishPrice();
	}
	
	public int vegetablePrice() {
		if(getVegetable().equalsIgnoreCase("Potato")) {
			return getName().length() * 2000;
		}else if(getVegetable().equalsIgnoreCase("Tomato")) {
			return getName().length() * 1000;
		}
		return vegetablePrice();
	}
	
}
