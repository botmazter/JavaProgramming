package main;

import java.util.ArrayList;
import java.util.Scanner;


import module.*;

public class Main {
	Scanner sc = new Scanner(System.in);
	ArrayList<FoodPerson> fpList = new ArrayList<>();
	int menuCounter = 1;
	
	public Main() {
		int menu = 0;
		do {
			System.out.println("Five Food Street");
			System.out.println("================");
			System.out.println("1. Insert New Menu");
			System.out.println("2. View All Menu");
			System.out.println("3. Sell Menu Item");
			System.out.println("4. Exit");
			System.out.print(">>");
			try {
				menu = sc.nextInt();
			} catch (Exception e) {
				// TODO: handle exception
			}
			sc.nextLine();
			
			switch (menu) {
			case 1:
				insertMenu();
				break;
			case 2: 
				viewMenu();
				break;
			case 3:
				sellMenu();
				break;
			case 4:
				System.exit(0);
				System.out.println("TY");
				break;
			}
		}while(menu != 4);
	}

	private void sellMenu() {
		if(fpList.isEmpty()) {
			System.out.println("No Menu Available");
		}else {
			view();
			
			int sell = 0;
			do {
				System.out.println("Input number [1 - " + fpList.size() + "]: ");
				sell = sc.nextInt(); sc.nextLine();
			}while(sell < 1 || sell > fpList.size());
			
			FoodPerson fperson = fpList.get(sell - 1);
			int qty;
			do {
				System.out.println("Input quantity: ");
				qty = sc.nextInt(); sc.nextLine();
			}while(qty <= 0);
		
			
			System.out.println("ID: " + fperson.getId());
			System.out.println("Menu Name: " + fperson.getName());
			System.out.println("Main dish: " + fperson.getDish());
			System.out.println("Price: " + fperson.getPrice());
			System.out.println("Grand Total: " + fperson.calculatePrice()*qty);
			
			fpList.remove(sell - 1);
			System.out.println("Food Sold");
		}
		
	}

	private void viewMenu() {
		if(fpList.isEmpty()) {
			System.out.println("No Menu Available");
		}else {
			view();
		}
	}
	
	private void view() {
		int i = 1;
		for(FoodPerson fperson : fpList) {
			System.out.println("");
			System.out.println("No: " + i);
			System.out.println("ID: " + fperson.getId());
			System.out.println("Name: " + fperson.getName());
			System.out.println("Price: " + fperson.getPrice());
			
			if(fperson instanceof Vege) {
				System.out.println("Type: Vege");
			}else if(fperson instanceof NonVege) {
				System.out.println("Type: Non-Vege");
			}		
		}
	}

	private void insertMenu() {
		String name;
		do {
			System.out.println("Input menu name [8-20]: ");
			name = sc.nextLine();
		}while(name.length() < 8 || name.length() > 20);
		
		String dish;
		do {
			System.out.println("Input main dish [Rice | Noodle] (case sensitive): ");
			dish = sc.nextLine();
		} while (!dish.equalsIgnoreCase("Rice") && !dish.equalsIgnoreCase("Noodle"));
		
		String type;
		do {
			System.out.println("Input menu type [Vege | Non-Vege] (case sensitive): ");
			type = sc.nextLine();
		}while(!type.equals("Vege") && !type.equals("Non-Vege"));
		
		int price;
		do {
			System.out.println("Input base price [5000 - 25000] (multiple of 1000): ");
			price = sc.nextInt(); sc.nextLine();
		} while (price < 5000 || price > 25000 || price % 1000 != 0);
		
		
		if(type.equals("Vege")) {
			String vegetable;
			do {
				System.out.println("Input vegetable [Potato | Tomato] (case insensitive): ");
				vegetable = sc.nextLine();
			}while(!vegetable.equalsIgnoreCase("Potato") && !vegetable.equals("Tomato"));
			
			
			String id = String.format("VV%03d", menuCounter++);
			
			Vege vege = new Vege(id, name, dish, price, vegetable);
			fpList.add(vege);
			
		}else if (type.equals("Non-Vege")){
			String meat;
			do {
				System.out.println("Input meat [Beef | Chicken | Pork] (case insensitive): ");
				meat = sc.nextLine();
			}while(!meat.equalsIgnoreCase("Beef") && !meat.equalsIgnoreCase("Chicken") && !meat.equalsIgnoreCase("Pork"));
			
			String addOns;
			do {
				System.out.println("Input meat [Meatballs | Fishballs | Fried Potato] (case insensitive): ");
				addOns = sc.nextLine();
				
			}while(!addOns.equalsIgnoreCase("Meatballs") && !addOns.equalsIgnoreCase("Fishballs") && !addOns.equalsIgnoreCase("Fried Potato"));
			
		
			String id = String.format("NV%03d", menuCounter++);
			
			NonVege nonVege = new NonVege(id, name, dish, price, meat, addOns);
			fpList.add(nonVege);
			
		}
		
	}

	public static void main(String[] args) {
		new Main();

	}

}
