package module;

public class Shirt extends Clothes{
	private String shirttype;
	
	public Shirt(String id, String name, String size, int price, String shirttype) {
		super(id, name, size, price);
		this.shirttype = shirttype;
	}

	public String getShirttype() {
		return shirttype;
	}

	public void setShirttype(String shirttype) {
		this.shirttype = shirttype;
	}

	@Override
	public double getFinalPrice() {
		if(this.getSize().equals("XL")) {
			return this.getPrice() + (5/100 * this.getPrice());
		}
		return this.getPrice();
	}

}
