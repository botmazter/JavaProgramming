package module;

public class Jacket extends Clothes{
	private String jackettype;

	public Jacket(String id, String name, String size, int price, String jackettype) {
		super(id, name, size, price);
		this.jackettype = jackettype;
	}

	public String getJackettype() {
		return jackettype;
	}

	public void setJackettype(String jackettype) {
		this.jackettype = jackettype;
	}

	@Override
	public double getFinalPrice() {
		if(jackettype.equals("Hoodie")) {
			return this.getPrice() * 1.1;
		}
		return this.getPrice();
	}

}
