package main;

import java.util.ArrayList;
import module.*;
import java.util.*;

public class Main {
	Scanner sc = new Scanner(System.in);
	ArrayList<Clothes> clothesList = new ArrayList<>();
	Random rand = new Random();

	public Main() {
		int menu = 0;
		while (menu != 5) {
			System.out.println("UniCloth");
			System.out.println("==================");
			System.out.println("1. Add new clothes");
			System.out.println("2. Update clothes");
			System.out.println("3. View all clothes");
			System.out.println("4. Remove clothes");
			System.out.println("5. Exit");
			System.out.print(">>");
			try {
				menu = sc.nextInt();
			} catch (Exception e) {
				System.out.println("Must input a number");
			}
			sc.nextLine();

			switch (menu) {
			case 1:
				addClothes();
				break;
			case 2:
				updateClothes();
				break;
			case 3:
				viewClothes();
				break;
			case 4:
				removeClothes();
				break;
			case 5:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid number");
				break;
			}
		}
	}

	private void removeClothes() {
		if(viewClothes()) {
			
			Clothes cloth;
			String id;
			do {
				System.out.println("Input ID to delete: ");
				id = sc.nextLine();
				
				cloth = findCloth(id);
			}while(findCloth(id) == null);
			
			clothesList.remove(cloth);
			
		}
	}

	private boolean viewClothes() {
		if (clothesList.isEmpty()) {
			System.out.println("No item");
			return false;
		}

		int no = 1;
		for (Clothes cloth : clothesList) {
			System.out.println("No " + String.format("%02d", no++));
			System.out.println("ID: " + cloth.getId());

			if (cloth instanceof Shirt) {
				Shirt shirt = (Shirt) cloth;
				System.out.println("Shirt name [5 - 20 ]: " + shirt.getName());
				System.out.println("Shirt type: " + shirt.getShirttype());
				System.out.println("Size: " + shirt.getSize());
				System.out.printf("Shirt price: %.2f\n", shirt.getFinalPrice());

			} else if (cloth instanceof Jacket) {
				Jacket jacket = (Jacket) cloth;
				System.out.println("Jacket name [5 - 20 ]" + jacket.getName());
				System.out.println("Jackettype: " + jacket.getJackettype());
				System.out.println("Size: " + jacket.getSize());
				System.out.printf("Jacket price: %.2f\n", jacket.getFinalPrice());
			}

		}
		return true;
	}

	private void updateClothes() {
		if (viewClothes()) {

			String id = null;
			Clothes cloth;
			do {
				System.out.println("Input ID to update [0 to return]: ");
				id = sc.nextLine();
				if (id.equals("0")) {
					return;
				}

				cloth = findCloth(id);
			} while (cloth == null);

			if (cloth instanceof Shirt) {

				String name;
				do {
					System.out.println("Shirt name [5 - 20 characters & ends with 'shirt']: ");
					name = sc.nextLine();
				} while (name.length() < 5 || name.length() > 20 || !name.endsWith("shirt"));

				String size;
				do {
					System.out.println("Shirt sleeve type [S | M | L | XL] (Case Sensitive): ");
					size = sc.nextLine();
				} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));

				String type;
				do {
					System.out.println("Shirt sleeve type [Short | Long]: ");
					type = sc.nextLine();
				} while (!type.equals("Short") && !type.equals("Long"));

				int price;
				do {
					System.out.println("Shirt price [30000 - 250000]: ");
					price = sc.nextInt();
					sc.nextLine();
				} while (price < 30000 || price > 250000);

				Shirt shirt = new Shirt(id, name, size, price, type);
				clothesList.set(clothesList.indexOf(shirt), shirt);
				
				System.out.println("Shirt " + cloth.getId() + " updated!");

				System.out.println("Press enter to continue...");
				sc.nextLine();
				
			}else if(cloth instanceof Jacket) {
				String name;
				do {
					System.out.println("Jacket name [5 - 20 characters & ends with 'Jacket']: ");
					name = sc.nextLine();
				} while (name.length() < 5 || name.length() > 20 || !name.endsWith("Jacket"));

				String size;
				do {
					System.out.println("Jacket size [S | M | L | XL] (Case Sensitive): ");
					size = sc.nextLine();
				} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));

				String type;
				do {
					System.out.println("Jacket type [Bomber | Hoodie]: ");
					type = sc.nextLine();
				} while (!type.equals("Bomber") && !type.equals("Hoodie"));

				int price;
				do {
					System.out.println("Jacket price [30000 - 250000]: ");
					price = sc.nextInt();
					sc.nextLine();
				} while (price < 30000 || price > 250000);

				Jacket jacket = new Jacket(id, name, size, price, type);
				clothesList.set(clothesList.indexOf(cloth), jacket);
				
				System.out.println("Jacket " + cloth.getId() + " updated!");

				System.out.println("Press enter to continue...");
				sc.nextLine();
				
			}
		}
	}

	private void addClothes() {
		int menu = 0;
		do {
			System.out.println("What kind of clothes you want to add?");
			System.out.println("=====================================");
			System.out.println("1. Shirt");
			System.out.println("2. Jacket");
			System.out.println("0. Back");
			System.out.print(">>");
			try {
				menu = sc.nextInt();
			} catch (Exception e) {

			}
			sc.nextLine();

			switch (menu) {
			case 1:
				addShirt();
				break;
			case 2:
				addJacket();
				break;
			}

		} while (menu != 0);
	}

	private void addJacket() {
		String name;
		do {
			System.out.println("Jacket name [5 - 20 characters & ends with 'Jacket']: ");
			name = sc.nextLine();
		} while (name.length() < 5 || name.length() > 20 || !name.endsWith("Jacket"));

		String size;
		do {
			System.out.println("Jacket size [S | M | L | XL] (Case Sensitive): ");
			size = sc.nextLine();
		} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));

		String type;
		do {
			System.out.println("Jacket type [Bomber | Hoodie]: ");
			type = sc.nextLine();
		} while (!type.equals("Bomber") && !type.equals("Hoodie"));

		int price;
		do {
			System.out.println("Jacket price [30000 - 250000]: ");
			price = sc.nextInt();
			sc.nextLine();
		} while (price < 30000 || price > 250000);

		String id;
		do {
			id = String.format("JKT%03d", rand.nextInt(1000));
		} while (findCloth(id) != null);

		Jacket jacket = new Jacket(id, name, size, price, type);
		clothesList.add(jacket);

		System.out.println("Press enter to continue...");
		sc.nextLine();

	}

	private void addShirt() {
		String name;
		do {
			System.out.println("Shirt name [5 - 20 characters & ends with 'shirt']: ");
			name = sc.nextLine();
		} while (name.length() < 5 || name.length() > 20 || !name.endsWith("shirt"));

		String size;
		do {
			System.out.println("Shirt size [S | M | L | XL] (Case Sensitive): ");
			size = sc.nextLine();
		} while (!size.equals("S") && !size.equals("M") && !size.equals("L") && !size.equals("XL"));

		String type;
		do {
			System.out.println("Shirt sleeve type [Short | Long]: ");
			type = sc.nextLine();
		} while (!type.equals("Short") && !type.equals("Long"));

		int price;
		do {
			System.out.println("Shirt price [30000 - 250000]: ");
			price = sc.nextInt();
			sc.nextLine();
		} while (price < 30000 || price > 250000);

		String id;
		do {
			id = String.format("SRT%03d", rand.nextInt(1000));
		} while (findCloth(id) != null);

		Shirt shirt = new Shirt(id, name, size, price, type);
		clothesList.add(shirt);

		System.out.println("Press enter to continue...");
		sc.nextLine();
	}

	private Clothes findCloth(String id) {
		for (Clothes cloth : clothesList) {
			if (cloth.getId().contains(id)) {
				return cloth;
			}
		}
		return null;
	}

	public static void main(String[] args) {
		new Main();
	}

}
