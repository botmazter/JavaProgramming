package main;
import java.util.*;


import module.*;

public class Main {
	Scanner sc = new Scanner(System.in);
	ArrayList<Status> statusList = new ArrayList<>();
	Random rand = new Random();
	
	public Main() {
		int menu = 0;
		do {
			System.out.println("Key Domain");
			System.out.println("==========");
			System.out.println("1. Add new member");
			System.out.println("2. View all members");
			System.out.println("3. Watch a movie");
			System.out.println("0. Exit");
			System.out.print(">>");
			try {
				menu = sc.nextInt();
			} catch (Exception e) {
				// TODO: handle exception
			}
			sc.nextLine();
			
			switch (menu) {
			case 1:
				addMember();
				break;
				
			case 2:
				viewMember();
				break;
				
			case 3:
				watchMovie();
				break;
			
			case 0:
				System.exit(0);
			}
			
		}while(menu != 0);
			
	}

	private void watchMovie() {
		if(statusList.isEmpty()) {
			System.out.println("There are no member");
			sc.nextLine();
		}else {
			view();
			
			String id;
			Status status;
			do {
				System.out.println("Input ID to update: ");
				id = sc.nextLine();
				
				if(getMemberID(id) == null) {
					System.out.println("There are no member with that ID");
				}
				
				status = getMemberID(id);
			}while(status == null);
			
			status.addPoints();
			System.out.println("Points added");
			
		}
		
		
		
	}

	private void viewMember() {
		if(statusList.isEmpty()) {
			System.out.println("There are no member");
			sc.nextLine();
		}else {
			view();
		}
		System.out.println("Press enter to continue..");
		sc.nextLine();
	}

	private void view() {
		int i = 1;
		for(Status status : statusList) {
			System.out.println("No: " + i);
			System.out.println("Name: " + status.getName());
			System.out.println("Gender: " + status.getGender());
			System.out.println("Phone Number: " + status.getPhone());
			
			if(status instanceof VIP) {
				VIP vip = (VIP) status;
				System.out.println("Status: VIP");
				System.out.println("ID: " + vip.getId());
				System.out.println("Points: " + vip.getPoints());
				System.out.println("Email: " + vip.getEmail());
				System.out.println("Lounge: " + vip.getLounge());
				System.out.println("Queue: " + vip.getQueue());
			}else if(status instanceof Regular) {
				Regular regular = (Regular) status;
				System.out.println("Status: regular");
				System.out.println("ID: " + regular.getId());
				System.out.println("Points: " + regular.getPoints());
				System.out.println("Email: -");
				System.out.println("Lounge: -");
				System.out.println("Queue: " + regular.getQueue());
			}
		}
	}
	
	private void addMember() {
		String name;
		do {
			System.out.println("Input your name [5 - 12 characters]: ");
			name =  sc.nextLine();
		}while(name.length() < 5 || name.length() > 12);
		
		String gender;
		do {
			System.out.println("Input your gender [Male | Female]: ");
			gender = sc.nextLine();
		}while(!gender.equals("Male") && !gender.equals("Female"));
		
		String phone;
		do {
			System.out.println("Input your phone number [numeric]: ");
			phone = sc.nextLine();
		}while(!validatePhone(phone));
		
		String status;
		do {
			System.out.println("Input your status [VIP / Regular] (case sensitive): ");
			status = sc.nextLine();
		}while(!status.equals("VIP") && !status.equals("Regular"));
		
		if(status.equals("VIP")) {
			String email;
			do {
				System.out.println("Input your email (ends with @gmail.com): ");
				email = sc.nextLine();
			}while(!email.endsWith("@gmail.com"));
			

			String id = String.format("V%05d", rand.nextInt(100000));
			System.out.println(id);
			
			String lounge = String.format("Lounge %d%d%d", rand.nextInt(4), rand.nextInt(4), rand.nextInt(4));
			System.out.println(lounge);
			
			int queue = 0;
			int points = 0;
			
			VIP vip = new VIP(id, name, gender, phone, queue, points, email, lounge);
			statusList.add(vip);
		
			
		}else if(status.equals("Regular")) {
			String id = String.format("Y%05d", rand.nextInt(100000));
			System.out.println(id);
			
			int queue = rand.nextInt(6);
			System.out.println(queue);
			
			int points = 0;
			
			Regular reg = new Regular(id, name, gender, phone, queue, points);
			statusList.add(reg);
		}
		
	}
	
	private boolean validatePhone(String phone) {
		boolean checkAlpha = false;
		boolean checkNum = false;
		if(phone.length() != 12) {
			return false;
		}
		for(int i = 0; i < phone.length(); i++) {
			if(!Character.isDigit(phone.charAt(i))) {
				return false;
			}
		}
		
//		For alphanumeric
//		for(int i = 0; i < phone.length(); i++) {
//			if(Character.isAlphabetic(phone.charAt(i))) {
//				checkAlpha = true;
//			}else if(Character.isDigit(phone.charAt(i))) {
//				checkNum = true;
//			}
//			
//			
//		}
			return true;
		
	}
	
	private Status getMemberID(String id) {
		for(Status status : statusList) {
			if(status.getId().equals(id)) {
				return status;
			}
		}
		return null;
		
	}

	public static void main(String[] args) {
		new Main();
		
	}

}
