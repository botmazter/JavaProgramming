package module;

public class Regular extends Status{

	public Regular(String id, String name, String gender, String phone, int queue, int points) {
		super(id, name, gender, phone, queue, points);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addPoints() {
		
		setPoints(getPoints() + getName().length());
	}

	
}
