package module;

public class VIP extends Status {
	private String email;
	private String lounge;
	
	public VIP(String id, String name, String gender, String phone, int queue, int points, String email,
			String lounge) {
		super(id, name, gender, phone, queue, points);
		this.email = email;
		this.lounge = lounge;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLounge() {
		return lounge;
	}

	public void setLounge(String lounge) {
		this.lounge = lounge;
	}

	@Override
	public void addPoints() {
		setPoints(getPoints() + getName().length() * 2);
	}

	
}
