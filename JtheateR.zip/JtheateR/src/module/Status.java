package module;

public abstract class Status {
	private String id, name, gender, phone;
	private int queue, points;

	public Status(String id, String name, String gender, String phone, int queue, int points) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.phone = phone;
		this.queue = queue;
		this.points = points;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}



	public int getQueue() {
		return queue;
	}



	public void setQueue(int queue) {
		this.queue = queue;
	}



	public int getPoints() {
		return points;
	}


	public void setPoints(int points) {
		this.points = points;
	}	
	
	public abstract void addPoints();
	
	
}
