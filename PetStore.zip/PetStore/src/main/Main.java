package main;
import java.util.*;

import module.*;

public class Main {
	Scanner sc = new Scanner(System.in);
	ArrayList <Pet> petList = new ArrayList<>();
	private double careCost;

	public Main() {
		int menu = 0;
		while(menu != 5) {
			System.out.println("1. Add new pet");
			System.out.println("2. View pets");
			System.out.println("3. Delete a pet");
			System.out.println("4. Update a pet");
			System.out.println("5. Exit");
			System.out.print(">>");
			try {
				menu = sc.nextInt(); sc.nextLine();
			} catch (Exception e) {
				sc.nextLine();
			}
		
			switch(menu) {
			case 1: 
				addPet();
				break;
			case 2: 
				viewPet();
				break;
			case 3: 
				deletePet();
				break;
			case 4: 
				updatePet();
				break;
			case 5: 
				System.exit(0);
				break;
			}
		}
	}
	
	public void updatePet() {
		if(petList.isEmpty()) {
			System.out.println("There is no pet on the list");
		}else {
			view();
			
			String searchName;
			do {
				System.out.println("Input pet name to update: ");
				searchName = sc.nextLine();
				
				Pet update = null;
				for(Pet pet : petList) {
					if(pet.getName().equalsIgnoreCase(searchName)) {
						update = pet;
					}
				}
				
				if(update != null) {
					int age;
					do {
						System.out.println("Input new age: " );
						age = sc.nextInt(); sc.nextLine();
					}while(age < 0);
				}
			}while(searchName == null);
		}
	}
	
	public void deletePet() {
		if(petList.isEmpty()) {
			System.out.println("There is no pet on the list");
		}else {
			view();

			
			int delete;
			do {
				System.out.println("Input index [1 - " + petList.size() + "]: ");
				delete = sc.nextInt();sc.nextLine();
			}while(delete < petList.size() || delete > petList.size());	
			
			petList.remove(delete - 1);	
		}
		System.out.println("Press Enter to continue...");
		sc.nextLine();
	}
	
	public void viewPet() {
		if(petList.isEmpty()) {
			System.out.println("There is no pet on the list");
		}else {
			view();
		}
		System.out.println("Press Enter to continue...");
		sc.nextLine();
	}
	
	public void view() {
		int i = 1;
		for(Pet pet: petList) {
			if(pet instanceof Dog) {
				Dog dog = (Dog) pet;
				System.out.println("No. " + i);
				System.out.println("Dog name: " + pet.getName());
				System.out.println("Dog age: " + pet.getAge());
				System.out.println("Dog IsTrained: " + dog.getIsTrained());
				System.out.println("Dog careCost: " + pet.getCareCost());
			}else if(pet instanceof Cat) {
				Cat cat = (Cat) pet;
				System.out.println("No. " + i);
				System.out.println("Cat name: " + pet.getName());
				System.out.println("Cat age: " + pet.getAge());
				System.out.println("Cat FurLength: " + cat.getFurLength());
				System.out.println("Cat careCost: " + pet.getCareCost());
			}
			System.out.println("");
			i++;
		}
	}
	
	public void addPet() {
		String type;
		do {
			System.out.println("Input pet type: ");
			type = sc.nextLine();
		}while(!type.equalsIgnoreCase("Dog") && !type.equalsIgnoreCase("Cat"));
		
		String name;
		do {
			System.out.println("Input pet name: ");
			name = sc.nextLine();
		}while(!checkName(name));
		
		int age;
		do {
			System.out.println("Input pet age: ");
			age = sc.nextInt(); sc.nextLine();
		}while(age < 0);
		
		String IsTrained;
		int furLength;
		switch(type) {
		case "Dog":
			do {
				System.out.println("Is Dog Trained [Untrained | Trained]: ");
				IsTrained = sc.nextLine();
			}while(!IsTrained.equalsIgnoreCase("Trained") && !IsTrained.equalsIgnoreCase("Untrained"));
			
			Dog dog = new Dog(name, age, careCost, IsTrained);
			petList.add(dog);	
			break;
			
		case "Cat":
			do {
				System.out.println("Input cat's furlength: ");
				furLength = sc.nextInt(); sc.nextLine();
			}while(furLength > 20);
			
			Cat cat = new Cat(name, age, careCost, furLength);
			petList.add(cat);
		
			break;
			
		default:
			System.out.println("Invalid input.");
			break;
		}
	}
	
	//jika nama harus alphabetic
	public boolean checkName(String name) {
		if(name.length() < 3 || name.length() > 30) {
			return false;
		}
		for(char c : name.toCharArray()) {
			if(!Character.isAlphabetic(c)) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		new Main();

	}

}
