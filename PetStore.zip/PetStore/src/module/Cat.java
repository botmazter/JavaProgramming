package module;

public class Cat extends Pet{
	private int furLength;
	
	public Cat(String name, int age, double careCost, int furLength) {
		super(name, age, careCost);
		this.furLength = furLength;
		this.careCost = calculateCareCost();
	}
	@Override
	public double calculateCareCost() {
		return careCost = furLength*10;
	}
	
	public int getFurLength() {
		return furLength;
	}
	public void setFurLength(int furLength) {
		this.furLength = furLength;
	}
	
	
}
