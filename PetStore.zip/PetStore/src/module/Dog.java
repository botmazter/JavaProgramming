package module;

public class Dog extends Pet{
	private String IsTrained;

	public Dog(String name, int age, double careCost, String isTrained) {
		super(name, age, careCost);
		this.IsTrained = isTrained;
		this.careCost = calculateCareCost();
	}

	@Override
	public double calculateCareCost() {
		if(IsTrained.equalsIgnoreCase("Trained")) {
			return 100;
		}else if(IsTrained.equalsIgnoreCase("Untrained")) {
			return 200;
		}
		return careCost;
	}

	public String getIsTrained() {
		return IsTrained;
	}

	public void setIsTrained(String isTrained) {
		IsTrained = isTrained;
	}

	
	
}
