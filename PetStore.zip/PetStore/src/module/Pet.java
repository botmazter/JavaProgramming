package module;

public abstract class Pet {
	private String name;
	private int age;
	protected double careCost;
	
	public Pet(String name, int age, double careCost) {
		super();
		this.name = name;
		this.age = age;
		this.careCost = careCost;
	}
	
	public abstract double calculateCareCost();
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getCareCost() {
		return careCost;
	}

	public void setCareCost(double careCost) {
		this.careCost = careCost;
	}

	
}
